# StoriIA v2 — Pacchetto di progetto per Antigravity CLI

## Nota onesta prima di iniziare

L'MVP che hai definito ora (generazione storie AI, personaggi preset+custom,
ambientazioni preset+custom, profili genitore/bambino, uso personale con tua
figlia) è **molto più snello** di tutto ciò che avevamo costruito nelle fasi
precedenti (billing, legal, admin, notifiche, moderazione). Questo è corretto:
per un test con la tua famiglia, non ti servono pagine legali, Stripe,
pannello admin o sistema crediti. Quella roba serve a partire dal momento in
cui inviti utenti che non conosci — non prima. Questo pacchetto riflette
quello scoping reale: MVP minimo e verificabile in giorni, non mesi.

## File in questo pacchetto

1. `01_PRD.md` — visione prodotto, i 3 blocchi (MVP/v1/v2), economia, wedge competitivo
2. `02_data_model.md` — schema Supabase completo, tabella per tabella, con nota su quando introdurla (MVP/v1/v2)
3. `03_roadmap_antigravity.md` — i prompt esatti da dare all'agente, in ordine, fase per fase
4. `04_skills/` — contenuto delle skill da creare in `~/.gemini/config/skills/`
5. `05_config.example.ts` — struttura del file di configurazione centralizzato

## Come procedere con Antigravity CLI

1. Crea le skill descritte in `04_skills/` copiandole nella directory skill globale del tuo Antigravity CLI
2. Apri una sessione nel progetto vuoto, incolla il contenuto di `01_PRD.md` come primo messaggio di contesto
3. Segui `03_roadmap_antigravity.md` nell'ordine indicato — un prompt per fase, mai "fai tutto insieme"
4. Dopo ogni fase, chiedi sempre: "Mostrami cosa hai testato, non solo cosa hai scritto" — non accettare "fatto" senza verifica (screenshot, test eseguiti, log)
5. Non passare alla fase successiva finché non hai testato tu stesso manualmente quella precedente

## Cosa NON fare

- Non dare in pasto tutto il PRD (compreso v2) all'agente chiedendo di costruire tutto insieme — usa solo il blocco MVP finché non lo hai testato con tua figlia
- Non attivare il livello di log massimo in modo permanente — solo temporaneamente in fase di debug
- Non salvare mai API key in file versionati o in tabelle DB gestite da UI — solo variabili d'ambiente
