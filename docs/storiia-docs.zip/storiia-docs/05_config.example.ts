/**
 * StoriIA — Configurazione centralizzata dell'applicazione.
 *
 * Regola: NESSUNA API key va qui dentro. Le API key restano SEMPRE in
 * variabili d'ambiente (.env, mai committate) o in un secret manager.
 * Questo file contiene solo parametri di comportamento, limiti,
 * feature flag — cose che puoi cambiare senza toccare segreti.
 */

export const config = {
  // --- MVP ---
  generation: {
    // Rete di sicurezza anti-abuso, NON leva di business
    dailyGenerationLimitPerFamily: 20,
    defaultTargetAgeRanges: ["0-3", "4-6", "7-10"] as const,
  },

  kidMode: {
    // Sezioni libreria in modalità bambino
    sections: ["new", "in_progress", "completed"] as const,
    // Ogni quanti secondi salvare il progresso di lettura (debounce)
    readingProgressSaveIntervalSeconds: 8,
  },

  logging: {
    // "basic" in produzione di default. "verbose" solo temporaneamente
    // per debug, mai lasciato acceso in modo permanente.
    level: "basic" as "basic" | "verbose",
    // Se verbose, per quanti giorni tenere i log prima di cancellarli
    verboseLogRetentionDays: 7,
    // Campi che vanno SEMPRE redatti prima di finire in un log,
    // indipendentemente dal livello
    redactedFields: ["childName", "generatedText", "moralLessonNote"],
  },

  // --- v1 (attivare quando si passa al blocco v1 del PRD) ---
  credits: {
    enabled: false, // true quando si attiva il blocco v1
    expirationEnabled: false, // deciso: i crediti non scadono, mai true senza conferma esplicita
    freeTier: {
      childProfilesLimit: 1,
      oneTimeSignupCredits: 5,
    },
    premiumTier: {
      childProfilesLimit: 3,
    },
    familyTier: {
      childProfilesLimit: 6,
    },
    addonProfilePriceEnabled: true,
  },

  gamification: {
    enabled: false, // true quando si attiva il blocco v1
    maxFreeStoriesFromPointsPerMonth: 1,
  },

  moderation: {
    enabled: false, // true quando si attiva il blocco v1 — NON lanciare mai pubblicamente senza questo a true
    autoRetryOnBlock: true,
    maxAutoRetries: 1,
  },

  // --- v2 ---
  admin: {
    enabled: false,
    // Ricorda: anche qui, mai API key gestibili da questa superficie
  },
} as const;
